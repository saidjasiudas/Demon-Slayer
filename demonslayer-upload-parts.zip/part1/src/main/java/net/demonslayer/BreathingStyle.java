package net.demonslayer;

import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Jedes Schwert hat dieselben drei Features:
 *  1) Passiv: Effekt beim Treffen (onHit)
 *  2) Aktiv: Spezialangriff per Rechtsklick (active) mit Cooldown
 *  3) Eigenes Rezept + Eintrag im Rezeptbuch (siehe data/.../recipe)
 */
public enum BreathingStyle {
    FROST(200, (sl, a, t) -> {
        t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 2));
        t.setTicksFrozen(t.getTicksRequiredToFreeze() + 60);
    }, (sl, p) -> {
        for (LivingEntity e : near(sl, p, 5)) {
            e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 140, 3));
            e.setTicksFrozen(e.getTicksRequiredToFreeze() + 100);
        }
        sl.sendParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 80, 2.5, 0.6, 2.5, 0.05);
    }),

    FLAME(180, (sl, a, t) -> t.igniteForSeconds(6), (sl, p) -> {
        Vec3 look = p.getLookAngle();
        for (int i = 1; i <= 8; i++) {
            Vec3 pos = p.position().add(look.scale(i)).add(0, 1, 0);
            sl.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 12, 0.4, 0.4, 0.4, 0.02);
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(pos, pos).inflate(1.2), x -> x != p && x.isAlive())) {
                e.igniteForSeconds(8);
                e.hurtServer(sl, sl.damageSources().playerAttack(p), 6f);
            }
        }
    }),

    AMETHYST(160, (sl, a, t) -> t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1)), (sl, p) -> {
        dash(p, 2.0);
        p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 40, 1));
        sl.sendParticles(ParticleTypes.WITCH, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.6, 0.6, 0.1);
    }),

    BLOSSOM(220, (sl, a, t) -> a.heal(1.5f), (sl, p) -> {
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 2));
        for (Player o : sl.getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(6)))
            o.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1));
        sl.sendParticles(ParticleTypes.CHERRY_LEAVES, p.getX(), p.getY() + 1.5, p.getZ(), 60, 2, 1, 2, 0.02);
    }),

    WATER(140, (sl, a, t) -> t.knockback(0.8, a.getX() - t.getX(), a.getZ() - t.getZ()), (sl, p) -> {
        dash(p, 1.8);
        p.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 160, 0));
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, 100, 1));
        sl.sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 60, 0.8, 0.5, 0.8, 0.2);
    }),

    INSECT(200, (sl, a, t) -> t.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 1)), (sl, p) -> {
        for (LivingEntity e : near(sl, p, 4)) {
            e.addEffect(new MobEffectInstance(MobEffects.POISON, 200, 2));
            e.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 120, 0));
        }
        sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, p.getX(), p.getY() + 1, p.getZ(), 80, 2, 0.5, 2, 0.01);
    }),

    STONE(240, (sl, a, t) -> t.knockback(1.6, a.getX() - t.getX(), a.getZ() - t.getZ()), (sl, p) -> {
        for (LivingEntity e : near(sl, p, 5)) {
            e.hurtServer(sl, sl.damageSources().playerAttack(p), 8f);
            e.setDeltaMovement(e.getDeltaMovement().add(0, 0.8, 0));
            e.hurtMarked = true;
        }
        sl.sendParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY() + 0.2, p.getZ(), 6, 2, 0.1, 2, 0.0);
    }),

    SUN(300, (sl, a, t) -> {
        t.igniteForSeconds(4);
        a.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 60, 0));
    }, (sl, p) -> {
        p.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0));
        sl.sendParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 60, 0.8, 1, 0.8, 0.05);
    }),

    THUNDER(200, (sl, a, t) -> {
        if (sl.random.nextFloat() < 0.15f) strike(sl, t);
    }, (sl, p) -> {
        Vec3 end = p.position().add(p.getLookAngle().scale(6));
        dash(p, 2.4);
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(sl, EntitySpawnReason.TRIGGERED);
        if (b != null) { b.snapTo(end.x, end.y, end.z); sl.addFreshEntity(b); }
    }),

    MIST(180, (sl, a, t) -> t.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0)), (sl, p) -> {
        p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 160, 0));
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, 160, 1));
        sl.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 60, 0.7, 0.8, 0.7, 0.02);
    });

    public interface Passive { void onHit(ServerLevel sl, LivingEntity attacker, LivingEntity target); }
    public interface Active { void use(ServerLevel sl, Player player); }

    public final int cooldown;
    public final Passive passive;
    public final Active active;

    BreathingStyle(int cooldown, Passive passive, Active active) {
        this.cooldown = cooldown;
        this.passive = passive;
        this.active = active;
    }

    private static List<LivingEntity> near(ServerLevel sl, Player p, double r) {
        return sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), e -> e != p && e.isAlive());
    }

    private static void dash(Player p, double power) {
        p.setDeltaMovement(p.getLookAngle().scale(power).add(0, 0.15, 0));
        p.hurtMarked = true;
    }

    private static void strike(ServerLevel sl, LivingEntity target) {
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(sl, EntitySpawnReason.TRIGGERED);
        if (b != null) { b.snapTo(target.getX(), target.getY(), target.getZ()); sl.addFreshEntity(b); }
    }
}

package net.demonslayer;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;

public class DemonSlayerMod implements ModInitializer {
    public static final String MOD_ID = "demonslayer";

    @Override
    public void onInitialize() {
        ModItems.init();
        ModLoot.init();

        // Unlock every mod recipe in the crafting table's recipe book on join
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                handler.player.awardRecipes(server.getRecipeManager().getRecipes()));

        // Outfit + mask effects, refreshed once per second
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 20 != 0) return;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) WornEffects.apply(p);
        });
    }
}

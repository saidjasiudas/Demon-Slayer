package net.demonslayer;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemKilledByPlayerCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

/**
 * Where the crafting materials can be found (no world generation needed):
 *  Haori Cloth        - village chests, woodland mansions, pillager outposts
 *  Wisteria Bloom     - village chests, woodland mansions, cherry/azalea leaves
 *  Demon Blood Shard  - dungeons, mineshafts, strongholds, temples + undead/spider mob drops
 *  Oni Horn           - raid mobs (vindicator, evoker, ravager, pillager), outposts, mansions
 */
public final class ModLoot {
    public static void init() {
        LootTableEvents.MODIFY.register((key, builder, source, registries) -> {
            String id = idOf(key);

            if (id.startsWith("minecraft:chests/village/")) {
                chest(builder, ModItems.HAORI_CLOTH, 0.55f, 1, 3);
                chest(builder, ModItems.WISTERIA_BLOOM, 0.25f, 1, 2);
            }
            switch (id) {
                case "minecraft:chests/woodland_mansion" -> {
                    chest(builder, ModItems.HAORI_CLOTH, 0.80f, 2, 4);
                    chest(builder, ModItems.WISTERIA_BLOOM, 0.50f, 1, 3);
                    chest(builder, ModItems.ONI_HORN, 0.35f, 1, 2);
                }
                case "minecraft:chests/pillager_outpost" -> {
                    chest(builder, ModItems.HAORI_CLOTH, 0.50f, 1, 2);
                    chest(builder, ModItems.ONI_HORN, 0.40f, 1, 2);
                }
                case "minecraft:chests/simple_dungeon", "minecraft:chests/abandoned_mineshaft",
                     "minecraft:chests/stronghold_corridor", "minecraft:chests/jungle_temple",
                     "minecraft:chests/desert_pyramid" ->
                    chest(builder, ModItems.DEMON_BLOOD_SHARD, 0.40f, 1, 3);

                case "minecraft:entities/zombie", "minecraft:entities/husk", "minecraft:entities/drowned",
                     "minecraft:entities/skeleton", "minecraft:entities/stray",
                     "minecraft:entities/spider", "minecraft:entities/cave_spider" ->
                    mob(builder, ModItems.DEMON_BLOOD_SHARD, 0.06f);

                case "minecraft:entities/vindicator", "minecraft:entities/evoker",
                     "minecraft:entities/pillager" -> mob(builder, ModItems.ONI_HORN, 0.12f);
                case "minecraft:entities/ravager" -> mob(builder, ModItems.ONI_HORN, 0.40f);

                case "minecraft:blocks/cherry_leaves", "minecraft:blocks/flowering_azalea_leaves" ->
                    chest(builder, ModItems.WISTERIA_BLOOM, 0.04f, 1, 1);
                default -> { }
            }
        });
    }

    /** "ResourceKey[minecraft:loot_table / minecraft:entities/zombie]" -> "minecraft:entities/zombie" */
    private static String idOf(Object key) {
        String s = key.toString();
        int i = s.indexOf("/ ");
        return i < 0 ? s : s.substring(i + 2, s.length() - 1);
    }

    private static void chest(LootTable.Builder b, Item item, float chance, int min, int max) {
        b.withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1))
                .when(LootItemRandomChanceCondition.randomChance(chance))
                .add(LootItem.lootTableItem(item)
                        .apply(SetItemCountFunction.setCount(UniformGenerator.between(min, max)))));
    }

    private static void mob(LootTable.Builder b, Item item, float chance) {
        b.withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1))
                .when(LootItemKilledByPlayerCondition.killedByPlayer())
                .when(LootItemRandomChanceCondition.randomChance(chance))
                .add(LootItem.lootTableItem(item)));
    }

    private ModLoot() {}
}

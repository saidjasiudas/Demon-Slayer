package net.demonslayer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;

/** Passive effects granted while an outfit (chest) or mask (head) is worn. */
public final class WornEffects {
    public record E(Holder<MobEffect> effect, int amplifier) {}

    private static final Map<Item, List<E>> MAP = new HashMap<>();

    public static void add(Item item, E... effects) {
        MAP.put(item, List.of(effects));
    }

    /** Called once per second. 260 ticks keeps Night Vision from flickering. */
    public static void apply(ServerPlayer player) {
        for (EquipmentSlot slot : new EquipmentSlot[] {EquipmentSlot.CHEST, EquipmentSlot.HEAD}) {
            List<E> list = MAP.get(player.getItemBySlot(slot).getItem());
            if (list == null) continue;
            for (E e : list)
                player.addEffect(new MobEffectInstance(e.effect(), 260, e.amplifier(), true, false));
        }
    }

    private WornEffects() {}
}

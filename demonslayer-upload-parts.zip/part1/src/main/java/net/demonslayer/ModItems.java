package net.demonslayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import net.demonslayer.WornEffects.E;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModItems {
    /** Everything registered here shows up in the creative tab. */
    private static final List<Item> ALL = new ArrayList<>();

    public static final ToolMaterial NICHIRIN = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2031, 6.0f, 2.0f, 20, ItemTags.NETHERITE_TOOL_MATERIALS);

    public static final ResourceKey<EquipmentAsset> TANJIRO_ASSET =
            ResourceKey.create(EquipmentAssets.ROOT_ID, id("tanjiro"));

    public static final ArmorMaterial TANJIRO_MATERIAL = new ArmorMaterial(
            40,
            Map.of(ArmorType.BOOTS, 3, ArmorType.LEGGINGS, 6, ArmorType.CHESTPLATE, 8,
                    ArmorType.HELMET, 3, ArmorType.BODY, 11),
            20, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.0f, 0.1f,
            ItemTags.REPAIRS_NETHERITE_ARMOR, TANJIRO_ASSET);

    // ------------------------------------------------------------------ materials (found in the world)
    public static final Item HAORI_CLOTH       = plain("haori_cloth");
    public static final Item WISTERIA_BLOOM    = plain("wisteria_bloom");
    public static final Item DEMON_BLOOD_SHARD = plain("demon_blood_shard");
    public static final Item ONI_HORN          = plain("oni_horn");

    // ------------------------------------------------------------------ swords
    public static final Item FROST_BLADES = sword("frost_blades", BreathingStyle.FROST, 4f, -2.0f,
            "On hit: Freezing + Slowness", "Right-click: Frost Nova (slows nearby enemies)");
    public static final Item FLAME_KATANA = sword("flame_katana", BreathingStyle.FLAME, 4f, -2.4f,
            "On hit: sets the target on fire", "Right-click: Fire Wave");
    public static final Item AMETHYST_SWORD = sword("amethyst_sword", BreathingStyle.AMETHYST, 4f, -2.4f,
            "On hit: Weakness", "Right-click: Dash + Resistance");
    public static final Item BLOSSOM_KATANA = sword("blossom_katana", BreathingStyle.BLOSSOM, 3f, -2.0f,
            "On hit: heals you a little", "Right-click: Regeneration for you and nearby players");
    public static final Item WATER_KATANA = sword("water_katana", BreathingStyle.WATER, 4f, -2.2f,
            "On hit: knockback", "Right-click: Water Dash (Dolphin's Grace + Speed)");
    public static final Item INSECT_BLADES = sword("insect_blades", BreathingStyle.INSECT, 3f, -1.8f,
            "On hit: Poison", "Right-click: Poison Cloud");
    public static final Item STONE_FLAIL = sword("stone_flail", BreathingStyle.STONE, 8f, -3.2f,
            "On hit: heavy knockback", "Right-click: Ground Slam");
    public static final Item SUN_KATANA = sword("sun_katana", BreathingStyle.SUN, 5f, -2.4f,
            "On hit: burns the target, boosts your strength", "Right-click: Strength II + Fire Resistance");
    public static final Item THUNDER_KATANA = sword("thunder_katana", BreathingStyle.THUNDER, 4f, -2.2f,
            "On hit: 15% chance of a lightning strike", "Right-click: Lightning Dash");
    public static final Item MIST_KATANA = sword("mist_katana", BreathingStyle.MIST, 4f, -2.2f,
            "On hit: Blindness", "Right-click: Invisibility + Speed");

    // ------------------------------------------------------------------ outfits (chest slot)
    public static final Item TANJIRO_HAORI = outfitWithMaterial("tanjiro_haori", TANJIRO_MATERIAL, "Strength I, Speed I",
            new E(MobEffects.STRENGTH, 0), new E(MobEffects.SPEED, 0));
    public static final Item CORPS_UNIFORM = outfit("corps_uniform", 4, "Haste I",
            new E(MobEffects.HASTE, 0));
    public static final Item ZENITSU_HAORI = outfit("zenitsu_haori", 5, "Speed II",
            new E(MobEffects.SPEED, 1));
    public static final Item INOSUKE_OUTFIT = outfit("inosuke_outfit", 5, "Strength I, Jump Boost I",
            new E(MobEffects.STRENGTH, 0), new E(MobEffects.JUMP_BOOST, 0));
    public static final Item NEZUKO_KIMONO = outfit("nezuko_kimono", 5, "Regeneration I, Resistance I",
            new E(MobEffects.REGENERATION, 0), new E(MobEffects.RESISTANCE, 0));
    public static final Item GIYU_HAORI = outfit("giyu_haori", 5, "Dolphin's Grace, Water Breathing",
            new E(MobEffects.DOLPHINS_GRACE, 0), new E(MobEffects.WATER_BREATHING, 0));
    public static final Item SHINOBU_HAORI = outfit("shinobu_haori", 5, "Speed I, Jump Boost II",
            new E(MobEffects.SPEED, 0), new E(MobEffects.JUMP_BOOST, 1));
    public static final Item RENGOKU_HAORI = outfit("rengoku_haori", 6, "Fire Resistance, Strength I",
            new E(MobEffects.FIRE_RESISTANCE, 0), new E(MobEffects.STRENGTH, 0));
    public static final Item MITSURI_UNIFORM = outfit("mitsuri_uniform", 5, "Strength I, Absorption I",
            new E(MobEffects.STRENGTH, 0), new E(MobEffects.ABSORPTION, 0));
    public static final Item MUICHIRO_HAORI = outfit("muichiro_haori", 5, "Speed I, Slow Falling",
            new E(MobEffects.SPEED, 0), new E(MobEffects.SLOW_FALLING, 0));

    // ------------------------------------------------------------------ masks (head slot)
    public static final Item FOX_MASK = mask("fox_mask", "Night Vision",
            new E(MobEffects.NIGHT_VISION, 0));
    public static final Item HYOTTOKO_MASK = mask("hyottoko_mask", "Luck I",
            new E(MobEffects.LUCK, 0));
    public static final Item RED_ONI_MASK = mask("red_oni_mask", "Strength I",
            new E(MobEffects.STRENGTH, 0));
    public static final Item BLUE_ONI_MASK = mask("blue_oni_mask", "Resistance I",
            new E(MobEffects.RESISTANCE, 0));
    public static final Item HANNYA_MASK = mask("hannya_mask", "Haste I, Fire Resistance",
            new E(MobEffects.HASTE, 0), new E(MobEffects.FIRE_RESISTANCE, 0));
    public static final Item TENGU_MASK = mask("tengu_mask", "Jump Boost II, Slow Falling",
            new E(MobEffects.JUMP_BOOST, 1), new E(MobEffects.SLOW_FALLING, 0));
    public static final Item BOAR_MASK = mask("boar_mask", "Haste II",
            new E(MobEffects.HASTE, 1));

    // ------------------------------------------------------------------ helpers
    private static Identifier id(String name) {
        return Identifier.fromNamespaceAndPath(DemonSlayerMod.MOD_ID, name);
    }

    private static ItemLore lore(String... lines) {
        return new ItemLore(Arrays.stream(lines)
                .map(s -> (Component) Component.literal(s).withStyle(ChatFormatting.GRAY))
                .toList());
    }

    private static Item reg(String name, Item.Properties props, java.util.function.Function<Item.Properties, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
        Item item = Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
        ALL.add(item);
        return item;
    }

    private static Item plain(String name) {
        return reg(name, new Item.Properties(), Item::new);
    }

    private static Item sword(String name, BreathingStyle style, float damage, float speed,
                              String passive, String active) {
        return reg(name,
                new Item.Properties().sword(NICHIRIN, damage, speed)
                        .component(DataComponents.LORE,
                                lore(passive, active, "Cooldown: " + style.cooldown / 20 + "s")),
                p -> new BreathingSword(p, style));
    }

    private static ArmorMaterial material(String asset, int durability, int chest, int head) {
        ResourceKey<EquipmentAsset> key = ResourceKey.create(EquipmentAssets.ROOT_ID, id(asset));
        return new ArmorMaterial(durability,
                Map.of(ArmorType.BOOTS, 0, ArmorType.LEGGINGS, 0, ArmorType.CHESTPLATE, chest,
                        ArmorType.HELMET, head, ArmorType.BODY, 0),
                15, SoundEvents.ARMOR_EQUIP_LEATHER, 0.0f, 0.0f, ItemTags.REPAIRS_LEATHER_ARMOR, key);
    }

    private static Item outfitWithMaterial(String name, ArmorMaterial mat, String effectText, E... effects) {
        Item item = reg(name,
                new Item.Properties().humanoidArmor(mat, ArmorType.CHESTPLATE)
                        .component(DataComponents.LORE, lore("When worn: " + effectText)),
                Item::new);
        WornEffects.add(item, effects);
        return item;
    }

    private static Item outfit(String name, int defense, String effectText, E... effects) {
        return outfitWithMaterial(name, material(name, 300, defense, 0), effectText, effects);
    }

    private static Item mask(String name, String effectText, E... effects) {
        Item item = reg(name,
                new Item.Properties().humanoidArmor(material(name, 150, 0, 1), ArmorType.HELMET)
                        .component(DataComponents.LORE, lore("When worn: " + effectText)),
                Item::new);
        WornEffects.add(item, effects);
        return item;
    }

    public static void init() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
                ResourceKey.create(Registries.CREATIVE_MODE_TAB, id("main")),
                FabricItemGroup.builder()
                        .title(Component.translatable("itemGroup.demonslayer.main"))
                        .icon(() -> new ItemStack(SUN_KATANA))
                        .displayItems((ctx, entries) -> ALL.forEach(entries::accept))
                        .build());
    }

    private ModItems() {}
}

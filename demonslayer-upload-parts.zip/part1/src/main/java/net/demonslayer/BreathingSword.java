package net.demonslayer;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class BreathingSword extends Item {
    private final BreathingStyle style;

    public BreathingSword(Properties properties, BreathingStyle style) {
        super(properties);
        this.style = style;
    }

    @Override
    public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.hurtEnemy(stack, target, attacker);
        if (attacker.level() instanceof ServerLevel sl) style.passive.onHit(sl, attacker, target);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(stack)) return InteractionResult.PASS;
        if (level instanceof ServerLevel sl) {
            style.active.use(sl, player);
            player.getCooldowns().addCooldown(stack, style.cooldown);
        }
        player.swing(hand);
        return InteractionResult.SUCCESS;
    }
}
